Tier List 1.0.0 for Windows

Double-click TierList.exe. If SmartScreen appears, choose More info -> Run anyway.
Keep the console window open while you rank images. Close it to quit.
