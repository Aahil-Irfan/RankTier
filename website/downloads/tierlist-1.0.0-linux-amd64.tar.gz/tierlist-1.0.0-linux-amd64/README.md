# Tier List 1.0.0

1. Run `./tierlist` or `./install.sh`
2. A browser window opens on a local address
3. Add images and drag them into S–F tiers
4. Press Ctrl+C in the terminal to quit

See docs at the project website or the repo README.
